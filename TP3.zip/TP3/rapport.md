# Comparaison des Approches pour les Cartes de Disparités

## 1. SGBM (Semi-Global Block Matching)  
SGBM est une méthode classique pour calculer des cartes de disparité, adaptée aux applications en temps réel ou avec des ressources limitées. Il utilise des blocs pour estimer les disparités en minimisant une fonction de coût global. Cette approche est rapide et simple à implémenter avec OpenCV, ne nécessite pas de données annotées, ce qui réduit les coûts. Ses Inconvénients sont: moins précis dans les zones de faible texture ou d’occlusion, les cartes produites sont souvent bruitées et manquent de détails fins, les performances dépendent des paramètres, nécessitant des ajustements pour chaque scène.  

---

## 2. Réseau Supervisé  
Nos réseaux supervisés '1_simpleDisparityEstimator.nb' exploitent des données d’entraînement annotées pour prédire des cartes de disparité précises. Ils capturent des relations complexes dans les données, surpassant généralement les approches traditionnelles comme SGBM.  
Ils fournissent des résultats de haute précision, adaptés à des applications critiques. Mais cela nécessite des vérités terrains précises (e.g., données LIDAR), souvent coûteuses, entraînement gourmand en ressources (GPU et temps), complexité accrue pour le réglage des hyperparamètres...  
Cette approche est la plus performante en termes de précision, mais elle est réservée aux projets avec des ressources significatives et des besoins élevés en fiabilité.

---

## 3. Réseau par Distillation (pseudo-labels SGBM)  
Notre modèle dans 2_simpleDisparitySGBM.nb consiste à utiliser les cartes SGBM comme pseudo-labels pour entraîner un réseau, réduisant ainsi la dépendance aux vérités terrains. Le modèle corrige certaines erreurs de SGBM tout en bénéficiant de sa rapidité. Cela réduit les coûts liés à l’acquisition de données annotées, le modèle entraîné est plus rapide et précis que SGBM seul. C'est une bonne alternative pour des projets à budget modéré.    
Mais le modèle hérite des limitations de SGBM : bruit, erreurs dans les zones d’occlusion, la précision reste inférieure à celle du modèle dans 1_simpleDisparityEstimator.nb, et cela dépend des pseudo-labels, limitant la généralisation dans certains cas.  

En général, la distillation est un compromis efficace, particulièrement lorsque les ressources pour des annotations LIDAR sont limitées, tout en nécessitant des efforts d'entraînement modérés.
